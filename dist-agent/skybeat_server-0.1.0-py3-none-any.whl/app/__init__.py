"""SkyBeat central application."""
