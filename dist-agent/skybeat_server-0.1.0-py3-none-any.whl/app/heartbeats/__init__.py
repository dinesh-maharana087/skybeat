"""Heartbeat ingestion domain."""
