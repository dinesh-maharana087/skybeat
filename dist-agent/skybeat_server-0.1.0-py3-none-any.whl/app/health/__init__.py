"""Server-authoritative availability evaluation."""
