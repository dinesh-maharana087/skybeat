"""Strict external wire schemas."""
