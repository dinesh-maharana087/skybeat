"""Bounded local telemetry collectors."""
